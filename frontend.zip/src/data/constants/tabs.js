export const tabs = [
  {
    title:"About Us",
    context:`
        About Us
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `
  },
  {
    title:"Vision and Mission",
    context:`
        Vision and Mission
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `
  },
  {
    title:"Our History",
    context:`
        Our History
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `
  },
    
];