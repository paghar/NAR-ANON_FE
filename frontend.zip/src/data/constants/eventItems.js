export const eventItems = [
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  },
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  },
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  },
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  },
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  },
  {
    id: 1,
    attributes: {
      title: "Application coaching information",
      thumbnail: "/assets/event1.jpeg",
      description: `We regularly hold free information seminars on the subject of applications.
      In about an hour we provide information about the possibilities and challenges in the search for the right job.`
    }
  }
];
