export const members = [
  {
    id:1,
    name:"fatemeh paghar",
    postion:"Front End Developer",
    description:`
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `,
    imageURL:`https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880&q=80`

  },
  {
    id:2,
    name:"fatemeh paghar",
    postion:"Front End Developer",
    description:`
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `,
    imageURL:`https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880&q=80`

  },
  {
    id:3,
    name:"fatemeh paghar",
    postion:"Front End Developer",
    description:`
        We regularly hold free information seminars on the subject of applications.
        In about an hour we provide information about the possibilities and challenges in the search for the right job.
    `,
    imageURL:`https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880&q=80`

  },    
];