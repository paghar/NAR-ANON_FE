export const projectItems = [
  {
    name: "Registration", 
    details: `Lorem ipsum dolor sit amet consectetur adipisicing elit. 
              Deleniti consequuntur praesentium at ratione numquam.Lorem ipsum dolor sit amet consectetur adipisicing elit. 
              Deleniti consequuntur praesentium at ratione numquam.`
  },
  {
    name: "Introduction",
    details: `Repellat, earum distinctio quidem voluptatem ad magni aperiam tenetur quia veniam maxime animi excepturi placeat repellendus alias, accusamus,
              optio eligendi saepe autem.Repellat, earum distinctio quidem voluptatem ad magni aperiam tenetur quia veniam maxime animi excepturi placeat repellendus alias,
              accusamus, optio eligendi saepe autem.`
  },
  {
    name: "Marketing meeting",
    details: `Tempore quisquam soluta voluptas saepe sit, velit accusamus at unde, nostrum, 
              alias explicabo rerum exercitationem officiis beatae optio natus.Tempore quisquam soluta voluptas saepe sit, 
              velit accusamus at unde, nostrum, alias explicabo rerum exercitationem officiis beatae optio natus.`
  },
  {
    name: "Financial reunion", 
    details: `Reiciendis ad perspiciatis facere temporibus necessitatibus consequatur ea cupiditate dolores quisquam voluptas.
              Reiciendis ad perspiciatis facere temporibus necessitatibus consequatur ea cupiditate dolores quisquam voluptas.`
  },
];