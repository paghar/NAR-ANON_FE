"use strict";
(() => {
var exports = {};
exports.id = 214;
exports.ids = [214,14];
exports.modules = {

/***/ 6014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ButtonOutline = ({
  id,
  type,
  onClick,
  addClass,
  children
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("button", {
    id: id,
    className: `font-medium tracking-wide py-2 px-5 sm:px-8 border
        border-orange-500 text-orange-500 bg-white-500 
        outline-none rounded-l-full rounded-r-full capitalize
        hover:bg-orange-500 hover:text-white-500 
        transition-all hover:shadow-orange ${addClass}`,
    type: type,
    onClick: onClick,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonOutline);

/***/ }),

/***/ 6163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const ButtonUnderline = ({
  id,
  type,
  onClick,
  addClass,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("button", {
    id: id,
    type: type,
    onClick: onClick,
    className: `
        group relative 
        px-5 py-2.5 border-none 
        bg-transparent outline-none 
        text-base text-black-500 
        hover:font-semibold active:top-0.5 active:outline-none focus:outline-none  ${addClass}
      `,
    children: [children, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
      className: "\r absolute top-full left-0 w-full h-0.5 border-2\r border-gray-500 transition-all duration-300 transform scale-90 group-hover:top-0 group-hover:scale-100\r ",
      "aria-hidden": "true"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
      className: "\r absolute top-full left-0 w-0.5 h-0 border-2 \r border-gray-500 transition-all duration-300 transform scale-90 group-hover:top-0 group-hover:h-full group-hover:scale-100",
      "aria-hidden": "true"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
      className: "\r absolute top-full right-0 w-0.5 h-0 border-2 \r border-gray-500 transition-all duration-300 transform scale-90 group-hover:top-0 group-hover:h-full group-hover:scale-100",
      "aria-hidden": "true"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
      className: "\r absolute top-full left-0 w-full h-0.5 border-2 \r border-gray-500 transition-all duration-300 transform scale-90 group-hover:scale-100",
      "aria-hidden": "true"
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonUnderline);

/***/ }),

/***/ 425:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_misc_ButtonUnderline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6163);
/* harmony import */ var _components_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6014);
/* harmony import */ var _hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2247);
/* harmony import */ var _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5036);
/* harmony import */ var _components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2013);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__, _components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_7__]);
([_hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__, _components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const gallary = () => {
  const {
    0: planSlug,
    1: setPlanSlug
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: pageLimit,
    1: setPageLimit
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(10);
  const {
    locale
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    data: plansData
  } = (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__/* .usePlans */ .x)({
    locale,
    pagination: `pagination[start]=0&pagination[limit]=${pageLimit}`
  });
  const plans = plansData?.data ?? [];
  const total = plansData?.meta.pagination.total ?? 0;
  const {
    data: galleries
  } = (0,_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__/* .useGalleries */ .n)({
    locale,
    filters: `filters\[plan\][slug][$contains]=${planSlug}`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
    className: "flex  mt-36 mb-4 px-8 xl:px-16 mx-auto",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
      className: "flex flex-col w-1/5  mx-4",
      children: [plans?.map(({
        id,
        attributes
      }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_misc_ButtonUnderline__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        id: String(id),
        type: "button",
        addClass: `mb-8`,
        onClick: () => setPlanSlug(attributes.slug),
        children: attributes.title
      }, id)), total > pageLimit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        type: "button",
        onClick: () => setPageLimit(prev => prev + 10),
        children: "load more"
      }), total <= pageLimit && pageLimit > 10 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        type: "button",
        onClick: () => setPageLimit(10),
        children: "close"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
      className: "w-10/12",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        galleries: galleries ?? []
      })
    })]
  });
};

async function getStaticProps({
  locale
}) {
  return {
    props: _objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__.serverSideTranslations)(locale ?? "de", ["common"]))
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (gallary);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7353:
/***/ ((module) => {

module.exports = import("react-photo-album");;

/***/ }),

/***/ 5717:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox");;

/***/ }),

/***/ 1485:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/fullscreen");;

/***/ }),

/***/ 5703:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/slideshow");;

/***/ }),

/***/ 5255:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/thumbnails");;

/***/ }),

/***/ 2208:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/zoom");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [247,640], () => (__webpack_exec__(425)));
module.exports = __webpack_exports__;

})();