(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9547:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7655);
/* harmony import */ var _misc_TextBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9219);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6860);
/* harmony import */ var _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3475);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__, _services_axios__WEBPACK_IMPORTED_MODULE_9__, _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__, _services_axios__WEBPACK_IMPORTED_MODULE_9__, _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var Facebook = function Facebook(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      fill: "none",
      d: "M0 0h24v24H0z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z",
      fill: "rgba(245,56,56,1)"
    })]
  }));
};

Facebook.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "24"
};

var Twitter = function Twitter(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      fill: "none",
      d: "M0 0h24v24H0z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M22.162 5.656a8.384 8.384 0 0 1-2.402.658A4.196 4.196 0 0 0 21.6 4c-.82.488-1.719.83-2.656 1.015a4.182 4.182 0 0 0-7.126 3.814 11.874 11.874 0 0 1-8.62-4.37 4.168 4.168 0 0 0-.566 2.103c0 1.45.738 2.731 1.86 3.481a4.168 4.168 0 0 1-1.894-.523v.052a4.185 4.185 0 0 0 3.355 4.101 4.21 4.21 0 0 1-1.89.072A4.185 4.185 0 0 0 7.97 16.65a8.394 8.394 0 0 1-6.191 1.732 11.83 11.83 0 0 0 6.41 1.88c7.693 0 11.9-6.373 11.9-11.9 0-.18-.005-.362-.013-.54a8.496 8.496 0 0 0 2.087-2.165z",
      fill: "rgba(245,56,56,1)"
    })]
  }));
};

Twitter.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "24"
};

var Instagram = function Instagram(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      fill: "none",
      d: "M0 0h24v24H0z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.217 2.428.465.66.254 1.216.598 1.772 1.153a4.908 4.908 0 0 1 1.153 1.772c.247.637.415 1.363.465 2.428.047 1.066.06 1.405.06 4.122 0 2.717-.01 3.056-.06 4.122-.05 1.065-.218 1.79-.465 2.428a4.883 4.883 0 0 1-1.153 1.772 4.915 4.915 0 0 1-1.772 1.153c-.637.247-1.363.415-2.428.465-1.066.047-1.405.06-4.122.06-2.717 0-3.056-.01-4.122-.06-1.065-.05-1.79-.218-2.428-.465a4.89 4.89 0 0 1-1.772-1.153 4.904 4.904 0 0 1-1.153-1.772c-.248-.637-.415-1.363-.465-2.428C2.013 15.056 2 14.717 2 12c0-2.717.01-3.056.06-4.122.05-1.066.217-1.79.465-2.428a4.88 4.88 0 0 1 1.153-1.772A4.897 4.897 0 0 1 5.45 2.525c.638-.248 1.362-.415 2.428-.465C8.944 2.013 9.283 2 12 2zm0 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm6.5-.25a1.25 1.25 0 0 0-2.5 0 1.25 1.25 0 0 0 2.5 0zM12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z",
      fill: "rgba(245,56,56,1)"
    })]
  }));
};

Instagram.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "24"
};









const schema = yup__WEBPACK_IMPORTED_MODULE_7__.object({
  name: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("errors.name-required"),
  email: yup__WEBPACK_IMPORTED_MODULE_7__.string().email().required("errors.email-required"),
  message: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("errors.message-required")
}).required();

const Footer = () => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
  const {
    control,
    handleSubmit,
    formState: {
      errors
    },
    reset
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
    defaultValues: {
      name: "",
      email: "",
      message: ""
    },
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__.yupResolver)(schema)
  });
  const addMessage = (0,react_query__WEBPACK_IMPORTED_MODULE_8__.useMutation)({
    mutationFn: newMessage => {
      return _services_axios__WEBPACK_IMPORTED_MODULE_9__/* ["default"].post */ .Z.post("/messages", newMessage);
    },
    onSuccess: () => {
      (0,_utils_ToastMessage__WEBPACK_IMPORTED_MODULE_10__/* .toastMessage */ .O)(t("message-registered"), "#4CAF50", 2000);
      reset();
    },
    onError: () => {
      (0,_utils_ToastMessage__WEBPACK_IMPORTED_MODULE_10__/* .toastMessage */ .O)(t("registration-failed"), "#d3010ad9", 2000);
    }
  });

  const onSubmit = data => {
    addMessage.mutate({
      data: {
        name: data.name,
        email: data.email,
        message: data.message
      }
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: "bg-white-300 pt-32 pb-20",
    id: "Contact",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "max-w-screen-xl px-6 sm:px-8 lg:px-16 my-24 mx-auto",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("section", {
        className: "text-gray-800",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "flex flex-wrap",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
            className: "grow-0 shrink-0 basis-auto mb-6 md:mb-0 w-full md:w-6/12 px-3 lg:px-6",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
              className: "text-3xl text-black-600 font-bold mb-6",
              children: t("contactUs.contactUs")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: "text-black-500 mb-6",
              dangerouslySetInnerHTML: {
                __html: t("contactUs.contactUs-dec")
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: "text-black-500 mb-6",
              dangerouslySetInnerHTML: {
                __html: t("contactUs.contactUs-help-text")
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: "text-black-500 mb-6",
              dangerouslySetInnerHTML: {
                __html: t("contactUs.contactUs-account")
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
              className: "text-black-500 mb-2",
              children: t("community.address")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
              className: "text-black-500 mb-2",
              children: t("community.phone")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
              className: "text-black-500 mb-2",
              children: t("community.email")
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: "flex w-full mt-2 mb-8 -mx-2",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Facebook, {
                  className: "h-6 w-6"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Twitter, {
                  className: "h-6 w-6"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Instagram, {
                  className: "h-6 w-6"
                })
              })]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: "grow-0 shrink-0 basis-auto mb-12 md:mb-0 w-full md:w-6/12 px-3 lg:px-6",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("form", {
              onSubmit: handleSubmit(onSubmit),
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                className: "form-group",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_5__.Controller, {
                  control: control,
                  rules: {
                    required: true,
                    maxLength: 30
                  },
                  render: ({
                    field: {
                      onChange,
                      value
                    }
                  }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    id: "name",
                    type: "input",
                    placeholder: t("contactUs.contactUs-name") ?? "contact us",
                    value: value,
                    onChange: onChange
                  }),
                  name: "name"
                }), errors.name && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
                  className: "text-red-500 text-lg",
                  children: t(errors.name.message)
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                className: "form-group",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_5__.Controller, {
                  control: control,
                  rules: {
                    required: true,
                    maxLength: 30
                  },
                  render: ({
                    field: {
                      onChange,
                      value
                    }
                  }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    id: "firstName",
                    type: "input",
                    placeholder: t("contactUs.contactUs-email") ?? "contact us",
                    value: value,
                    onChange: onChange
                  }),
                  name: "email"
                }), errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
                  className: "text-red-500 text-lg",
                  children: t(errors.email.message)
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                className: "form-group",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_5__.Controller, {
                  control: control,
                  rules: {
                    required: true
                  },
                  render: ({
                    field: {
                      onChange,
                      value
                    }
                  }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    id: "reasonText",
                    type: "textarea",
                    rows: 8,
                    placeholder: t("contactUs.contactUs-message"),
                    value: value,
                    onChange: onChange
                  }),
                  name: "message"
                }), errors.message && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
                  className: "text-red-500 text-lg",
                  children: t(errors.message.message)
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                  type: "submit",
                  onClick: () => null,
                  children: t("button.send")
                })
              })]
            })
          })]
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Header)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "react-scroll"
const external_react_scroll_namespaceObject = require("react-scroll");
// EXTERNAL MODULE: ./src/components/misc/ButtonOutline.tsx
var ButtonOutline = __webpack_require__(6014);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/Layout/Header.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







var LogoVPN = function LogoVPN(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("defs", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("style", {
        children: [".cls-3", `{`, "fill:#098955", `}`, ".cls-4", `{`, "fill:#14a36d", `}`, ".cls-5", `{`, "fill:#51c441", `}`, ".cls-6", `{`, "fill:#65e856", `}`, ".cls-7", `{`, "fill:#92f784", `}`, ".cls-8", `{`, "fill:#cfffc7", `}`, ".cls-9", `{`, "fill:#15be79", `}`, ".cls-10", `{`, "fill:#27e090", `}`, ".cls-11", `{`, "fill:#eea47d", `}`, ".cls-13", `{`, "fill:#f3c3b1", `}`, ".cls-14", `{`, "fill:#f5b890", `}`]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("circle", {
      cx: "256",
      cy: "256",
      r: "256",
      style: {
        fill: "#e52e44"
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("circle", {
      cx: "256",
      cy: "256",
      r: "205.64",
      style: {
        fill: "#fa4654"
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-3",
      d: "m382.56 331.27-20.2 20.19a8.69 8.69 0 0 1-.93.81 8.11 8.11 0 0 1-11.93-2.65L330 314l15.09-15.1 9.47 5.19 26.2 14.35a8.13 8.13 0 0 1 1.8 12.83z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-4",
      d: "m382.56 331.27-20.2 20.19a8.69 8.69 0 0 1-.93.81l-16-29.23a9.71 9.71 0 0 1 1.65-11.54l7.45-7.45 26.2 14.35a8.13 8.13 0 0 1 1.83 12.87z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-5",
      d: "M294 231.1v32h-32a122.26 122.26 0 0 1-122.33-122.25v-32h32A122.28 122.28 0 0 1 294 231.1z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-6",
      d: "M294 231.1v2.06l-2 .44a122.28 122.28 0 0 1-145.46-93.48l-6.8-31.28h32A122.28 122.28 0 0 1 294 231.1z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-7",
      cx: "187.77",
      cy: "132.29",
      rx: "12.85",
      ry: "21.94",
      transform: "rotate(-59.53 187.772 132.296)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-6",
      d: "m305.34 264.8 10.81 18.72 2.46 4.26-23 13.27A101.34 101.34 0 0 1 157.2 264l-13.27-23 15.9-9.18 7.08-4.09a101.34 101.34 0 0 1 138.43 37.07z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-7",
      d: "m305.34 264.8 10.81 18.72-7.07 4.08a101.34 101.34 0 0 1-138.44-37.09l-10.81-18.72 7.08-4.09a101.34 101.34 0 0 1 138.43 37.1z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-8",
      cx: "208.13",
      cy: "235.31",
      rx: "23.07",
      ry: "12.4",
      transform: "rotate(-6.31 207.948 235.195)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-5",
      d: "m295.63 274.51 18.72 10.81 4.26 2.46 13.27-23a101.33 101.33 0 0 0-37.1-138.43l-23-13.27-9.16 15.92-4.08 7.08a101.34 101.34 0 0 0 37.09 138.43z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-6",
      d: "m295.63 274.51 18.72 10.81 4.08-7.07a101.34 101.34 0 0 0-37.09-138.44L262.62 129l-4.08 7.08a101.34 101.34 0 0 0 37.09 138.43z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-7",
      cx: "266.15",
      cy: "177.3",
      rx: "23.07",
      ry: "12.4",
      transform: "rotate(-83.69 266.164 177.295)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-6",
      d: "M318.61 261.24v26.54h-26.53a101.35 101.35 0 0 1-101.35-101.34v-26.53h26.53a101.34 101.34 0 0 1 101.35 101.33z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-7",
      d: "M318.61 261.24V263l-1.67.36a101.35 101.35 0 0 1-120.57-77.48l-5.63-25.92h26.53a101.34 101.34 0 0 1 101.34 101.28z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-8",
      cx: "230.61",
      cy: "179.34",
      rx: "10.65",
      ry: "18.19",
      transform: "rotate(-59.53 230.605 179.347)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-3",
      d: "m318.61 287.78 18.76 18.76-18.76 18.76a101.32 101.32 0 0 1-143.31 0l-18.77-18.76 18.77-18.76a101.32 101.32 0 0 1 143.31 0z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-4",
      d: "m318.61 287.78 18.76 18.76-5.52 5.52a101.33 101.33 0 0 1-143.31 0l-18.76-18.76 5.52-5.52a101.32 101.32 0 0 1 143.31 0z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-9",
      cx: "221.5",
      cy: "286.07",
      rx: "25.91",
      ry: "14.37",
      transform: "rotate(-10.54 221.48 286.062)"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-9",
      cx: "273.03",
      cy: "288.92",
      rx: "7.94",
      ry: "18.66",
      transform: "rotate(-75 273.031 288.92)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-4",
      d: "m318.61 287.78 18.76 18.76 18.76-18.76a101.34 101.34 0 0 0 0-143.32l-18.76-18.76-18.76 18.76a101.34 101.34 0 0 0 0 143.32z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-9",
      d: "m318.61 287.78 18.76 18.76 5.52-5.52a101.33 101.33 0 0 0 0-143.31l-18.76-18.77-5.52 5.52a101.34 101.34 0 0 0 0 143.32z"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-10",
      cx: "316.9",
      cy: "190.66",
      rx: "25.91",
      ry: "14.37",
      transform: "rotate(-79.46 316.902 190.66)"
    }), /*#__PURE__*/jsx_runtime_.jsx("ellipse", {
      className: "cls-10",
      cx: "319.75",
      cy: "242.2",
      rx: "7.94",
      ry: "18.66",
      transform: "rotate(-15 319.75 242.197)"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-11",
      d: "M393.4 366.25a8.43 8.43 0 0 1-.66.71l-.25.25c-6.81 6.83-12.71 13.39-18 19.66-38.32 45.3-45.38 75.06-138.76 75.06-55.23 0-64.4 6.59-76 31.33-3.64-1.48-7.23-3-10.78-4.68a255 255 0 0 1-49.58-30.12q-6.4-4.95-12.48-10.31l48.34-48.33c63.75-63.74 84.9-50.57 96.35-50.57 6 0 14.93-5.47 22.17-10.73 6.69-4.84 11.9-9.5 11.9-9.5 3.62-3.62 7-5.55 9.92-6.19 8-1.74 13 6 12.09 14.83a22.42 22.42 0 0 1-6.56 13.62c-5.72 5.71-48.38 31-48.38 31h63.94c23.36 0 43.27-52.06 65.49-52.06 11.61 0 17.15 2.93 19.79 5.73a8 8 0 0 1 2.42 5l-2.6 3.05-.08.09-.31.38-.08.1-8.29 9.91h.31c1.91.13 12.07.92 17.81 3.69 3.66 1.83 5.51 4.36 2.28 8.08z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "m390.44 364.93-1.31-.53h-.06c-.73-.29-1.45-.56-2.14-.82l-.26-.1c-2.07-.75-3.84-1.32-5-1.7-5.74-1.95-13.28-1.14-13.28-1.14l4.7-5.85.21-.26 7.72-9.6.07-.1.18-.23.08-.1.31-.38c-.59-.47-1.33-1.08-2.2-1.65a12.18 12.18 0 0 0-2-1.09 9.35 9.35 0 0 0-3.65-.75c-22.21 0-45.86 56.55-69.22 56.55h-63.98s12.23-7.25 24.48-14.86h-32.41s42.66-25.26 48.38-31a22.42 22.42 0 0 0 6.56-13.62c-3.75-.85-8.61.74-14.09 6.22 0 0-22.62 20.23-34.07 20.23s-32.6-13.17-96.34 50.56l-43.79 43.75a255 255 0 0 0 49.58 30.12c3.55 1.65 7.14 3.2 10.78 4.68 11.63-24.74 20.8-31.33 76-31.33 93.38 0 100.44-29.76 138.76-75.06 5.3-6.27 11.2-12.83 18-19.66l.25-.25a8.43 8.43 0 0 0 .66-.71c-.94-.47-1.93-.91-2.92-1.32z",
      style: {
        fill: "#d48d77"
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-11",
      d: "M391.14 358.18c-.86 1.07-1.75 2.19-2.67 3.38l-1.52 2q-8.28 10.69-15.7 19.79c-52 63.69-75.41 71.07-118.15 71.07-82.45 0-92 5.24-104.17 34.16 3.55 1.65 7.14 3.2 10.78 4.68 11.63-24.74 20.8-31.33 76-31.33 93.38 0 100.44-29.76 138.76-75.06 5.3-6.27 11.2-12.83 18-19.66l.25-.25a8.43 8.43 0 0 0 .66-.71c3.25-3.72 1.4-6.25-2.24-8.07z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-11",
      d: "m384.32 340.91-2.55 3.09-.39.47-.08.1-8.22 9.92-8.25 9.95-26.52 32c-12.11 12.11-24.25 26-43.37 26 0 0 31.63-14.34 45.19-33.68 5.41-7.71 13.53-18.13 21.36-27.87l.42-.51c5.49-6.83 10.79-13.28 14.85-18.19l.39-.48.26-.32c1.8-2.17 3.33-4 4.49-5.39a8 8 0 0 1 2.42 4.91z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-13",
      d: "m274.54 335.31-5.2 5.2a9.65 9.65 0 0 1-13.65 0l-1.78-1.78-.2-.21c6.69-4.84 11.9-9.5 11.9-9.5 3.62-3.62 7-5.55 9.92-6.19a9.65 9.65 0 0 1-.99 12.48z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-14",
      d: "M382.07 344.27a9.65 9.65 0 0 0-13.65 0l-5.2 5.19c-3.77 3.77-4.65 10.47 1.62 15z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-13",
      d: "M381.77 344a9.57 9.57 0 0 0-4.63-2.37l-15.65 19.18a8.21 8.21 0 0 0 3.35 3.62z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-14",
      d: "M392.49 367.21c-6.81 6.83-12.71 13.39-18 19.66l-.21-.2-1.78-1.78a4.61 4.61 0 0 1-.37-.4q-.31-.35-.6-.72l-.29-.42a9.66 9.66 0 0 1 1.26-12.11l5.19-5.2a9.66 9.66 0 0 1 9-2.58l.28.07a9.74 9.74 0 0 1 2.16.86l.14.08a8.73 8.73 0 0 1 .94.6l.2.16.34.26.22.2.36.34z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      className: "cls-13",
      d: "M392.49 367.21c-6.81 6.83-12.71 13.39-18 19.66l-.21-.2-1.78-1.78a4.61 4.61 0 0 1-.37-.4q-.31-.35-.6-.72l-.29-.42q7.44-9.11 15.7-19.79a9.37 9.37 0 0 1 2.12.84h.05l.15.08a10.61 10.61 0 0 1 .94.6l.2.16.34.26.22.2.36.34z"
    })]
  }));
};

LogoVPN.defaultProps = {
  id: "Icons",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};






const Header = ({
  menuItems,
  subscribeClick
}) => {
  const {
    0: activeLink,
    1: setActiveLink
  } = (0,external_react_.useState)("");
  const {
    0: scrollActive,
    1: setScrollActive
  } = (0,external_react_.useState)(false);
  const {
    pathname,
    push
  } = (0,router_.useRouter)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", () => {
      setScrollActive(window.scrollY > 20);
    });
  }, []);

  const handleScroll = elem => {
    if (pathname !== "/" && elem !== "Contact") {
      push("/").then(() => {
        external_react_scroll_namespaceObject.scroller.scrollTo(elem, {
          duration: 1000,
          smooth: true,
          offset: true
        });
      });
    }
  };

  const renderMenuItems = (style, activeLinkStyle, linkStyle) => {
    return menuItems.map((item, index) => /*#__PURE__*/jsx_runtime_.jsx(external_react_scroll_namespaceObject.Link, {
      activeClass: "active",
      to: item.hrefText,
      spy: true,
      offset: -100,
      smooth: true,
      duration: 1000,
      onSetActive: () => {
        setActiveLink(item.hrefText);
      },
      className: `${style} ${activeLink === item.hrefText ? activeLinkStyle : linkStyle}`,
      onClick: () => handleScroll(item.hrefText),
      children: item.text
    }, `${item}${index}`));
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("header", {
      className: `fixed top-0 w-full  z-30 bg-white-500 transition-all${scrollActive ? " shadow-md pt-0" : " pt-4"}`,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
        className: "max-w-screen-xl px-6 sm:px-8 lg:px-16 mx-auto grid grid-flow-col py-3 sm:py-4",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-start-1 col-end-2 flex items-center",
          children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx(LogoVPN, {
              className: "w-12 h-12"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: "hidden lg:flex col-start-4 col-end-8 text-black-500  items-center",
          children: renderMenuItems("px-4 py-2 mx-2 cursor-pointer animation-hover inline-block relative", "text-orange-500 animation-active", "text-black-500 hover:text-orange-500 a")
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "col-start-10 col-end-12 font-medium flex justify-end items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: {
              pathname
            },
            locale: "de",
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-black-600 mx-1 sm:mx-2 capitalize tracking-wide hover:text-orange-500 transition-all",
              children: t("language.deutsch")
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "/"
          }), /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: {
              pathname
            },
            locale: "fa",
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-black-600 mx-1 sm:mx-2 capitalize tracking-wide hover:text-orange-500 transition-all",
              children: t("language.farsi")
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(ButtonOutline/* default */.Z, {
            type: "button",
            onClick: subscribeClick,
            children: t("membership.membership")
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("nav", {
      className: "fixed lg:hidden bottom-0 left-0 right-0 z-20 px-4 sm:px-8 shadow-t ",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bg-white-500 sm:px-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: "flex w-full justify-between items-center text-black-500",
          children: renderMenuItems("mx-1 sm:mx-2 px-3 sm:px-4 py-2 flex flex-col items-center text-xs border-t-2 transition-all", " border-orange-500 text-orange-500", "border-transparent")
        })
      })
    })]
  });
};

/* harmony default export */ const Layout_Header = (Header);

/***/ }),

/***/ 9702:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9547);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2762);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Footer__WEBPACK_IMPORTED_MODULE_0__]);
_Footer__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Layout = ({
  menuItems,
  children,
  subscribeClick
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      menuItems: menuItems,
      subscribeClick: subscribeClick
    }), children, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {})]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1800:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_SeoHead)
});

;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/SeoHead.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // Default value for some meta data




const defaultMeta = {
  title: "LaslesVPN",
  siteName: "LaslesVPN",
  description: "Landing page VPN LaslesVPN Best VPN For Privacy, Country and Cheapest",
  // change base url of your web (without '/' at the end)
  url: "https://next-landing-vpn.vercel.app",
  type: "website",
  robots: "follow, index",
  // change with url of your image (recommended dimension = 1.91:1)
  // used in twitter, facebook, etc. card when link copied in tweet/status
  image: "https://next-landing-vpn.vercel.app/assets/card-image.png",
  author: "Lorem Ipsum"
};
/**
 * Next Head component populated with necessary SEO tags and title
 * props field used:
 * - title
 * - siteName
 * - description
 * - url
 * - type
 * - robots
 * - image
 * - date
 * - author
 * - templateTitle
 * all field are optional (default value defined on defaultMeta)
 * @example
 * <SeoHead title="Page's Title" />
 */

const SeoHead = props => {
  const router = (0,router_.useRouter)();

  const meta = _objectSpread(_objectSpread({}, defaultMeta), props); // Use siteName if there is templateTitle
  // but show full title if there is none


  meta.title = props.templateTitle ? `${props.templateTitle} | ${meta.siteName}` : meta.title;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
    children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
      children: meta.title
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "robots",
      content: meta.robots
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      content: meta.description,
      name: "description"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:url",
      content: `${meta.url}${router.asPath}`
    }), /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "canonical",
      href: `${meta.url}${router.asPath}`
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:type",
      content: meta.type
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:site_name",
      content: meta.siteName
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:description",
      content: meta.description
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:title",
      content: meta.title
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "image",
      property: "og:image",
      content: meta.image
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:card",
      content: "summary_large_image"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:site",
      content: "@F2aldi"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:title",
      content: meta.title
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:description",
      content: meta.description
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:image",
      content: meta.image
    }), meta.date && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "article:published_time",
        content: meta.date
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "publish_date",
        property: "og:publish_date",
        content: meta.date
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "author",
        property: "article:author",
        content: meta.author
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("link", {
      href: "/favicon.ico",
      rel: "shortcut icon"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "msapplication-TileColor",
      content: "#F53838"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "msapplication-TileImage",
      content: "/favicon/ms-icon-144x144.png"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "theme-color",
      content: "#F53838"
    })]
  });
};

/* harmony default export */ const components_SeoHead = (SeoHead);

/***/ }),

/***/ 7655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ButtonPrimary = ({
  id,
  type,
  onClick,
  children,
  addClass
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("button", {
    id: id,
    className: `py-3 lg:py-4 px-12 lg:px-16 text-white-500 font-semibold rounded-lg 
        bg-orange-500 hover:shadow-orange-md transition-all outline-none ${addClass}`,
    type: type,
    onClick: onClick,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonPrimary);

/***/ }),

/***/ 7779:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9702);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_0__]);
_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const LayoutContainer = ({
  children
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
  const menuItems = [{
    text: t("navbar.about"),
    hrefText: "About"
  }, {
    text: t("navbar.gallery"),
    hrefText: "Gallery"
  }, {
    text: t("navbar.project"),
    hrefText: "Project"
  }, {
    text: t("navbar.event"),
    hrefText: "Event"
  }, {
    text: t("navbar.contact-us"),
    hrefText: "Contact"
  }];
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const subscribeClick = () => {
    router.push("/subscribe");
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
    menuItems: menuItems,
    subscribeClick: subscribeClick,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LayoutContainer);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1336:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6201);
/* harmony import */ var _container_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7779);
/* harmony import */ var _components_SeoHead__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1800);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(108);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_slick_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(844);
/* harmony import */ var _styles_slick_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_slick_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(483);
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var yet_another_react_lightbox_styles_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8069);
/* harmony import */ var yet_another_react_lightbox_styles_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(yet_another_react_lightbox_styles_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var yet_another_react_lightbox_plugins_thumbnails_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7357);
/* harmony import */ var yet_another_react_lightbox_plugins_thumbnails_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(yet_another_react_lightbox_plugins_thumbnails_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_3__, _container_Layout__WEBPACK_IMPORTED_MODULE_4__]);
([react_hot_toast__WEBPACK_IMPORTED_MODULE_3__, _container_Layout__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClient();

function App({
  Component,
  pageProps
}) {
  const {
    t,
    i18n: {
      dir,
      language
    }
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    document.dir = dir();
    document.body.className = language;
  }, [language]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClientProvider, {
      client: queryClient,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(react_query__WEBPACK_IMPORTED_MODULE_2__.Hydrate, {
        state: pageProps.dehydratedState,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_SeoHead__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          title: t("site-name")
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_container_Layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(Component, _objectSpread({}, pageProps)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_3__.Toaster, {
            containerStyle: {
              bottom: "12%"
            },
            toastOptions: {
              style: {
                width: "100%",
                boxShadow: "0px 4px 5px rgba(0, 0, 0, 0.14), 0px 1px 10px rgba(0, 0, 0, 0.12),0px 2px 4px rgba(0, 0, 0, 0.2)",
                borderRadius: "8px"
              }
            }
          })]
        })]
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.appWithTranslation)(App));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 483:
/***/ (() => {



/***/ }),

/***/ 7357:
/***/ (() => {



/***/ }),

/***/ 8069:
/***/ (() => {



/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 844:
/***/ (() => {



/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 1175:
/***/ ((module) => {

"use strict";
module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

"use strict";
module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,628,14], () => (__webpack_exec__(1336)));
module.exports = __webpack_exports__;

})();