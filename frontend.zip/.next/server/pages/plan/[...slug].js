"use strict";
(() => {
var exports = {};
exports.id = 79;
exports.ids = [79];
exports.modules = {

/***/ 8884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Plan),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2013);
/* harmony import */ var _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5036);
/* harmony import */ var _hooks_usePlans__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3135);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_0__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_1__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_2__, react_markdown__WEBPACK_IMPORTED_MODULE_5__]);
([_components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_0__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_1__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_2__, react_markdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









function Plan() {
  const {
    locale,
    query
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
  const slug = !!query?.slug?.length ? query.slug[0] : "";
  const {
    data: planData
  } = (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_2__/* .usePlans */ .x)({
    locale,
    pagination: `pagination[start]=0&pagination[limit]=0`,
    slug
  });
  const plan = planData?.data ?? {};
  const {
    attributes
  } = plan;
  const {
    data: galleries
  } = (0,_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_1__/* .useGalleries */ .n)({
    locale,
    filters: `filters\[plan\][slug][$contains]=${slug}`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
    className: "flex flex-col max-w-screen-xl mt-36 mb-4 px-8 xl:px-16 mx-auto",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("h2", {
      className: "text-5xl font-normal leading-normal mt-0 mb-2",
      children: attributes?.title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("small", {
      className: "font-normal leading-normal mt-0 mb-4",
      children: attributes?.description
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_5__["default"], {
        children: attributes?.content
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_GalleryAlbum__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
        galleries: galleries ?? []
      })
    })]
  });
}
async function getServerSideProps({
  locale
}) {
  return {
    props: _objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__.serverSideTranslations)(locale ?? "de", ["common"]))
  };
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3135:
/***/ ((module) => {

module.exports = import("react-markdown");;

/***/ }),

/***/ 7353:
/***/ ((module) => {

module.exports = import("react-photo-album");;

/***/ }),

/***/ 5717:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox");;

/***/ }),

/***/ 1485:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/fullscreen");;

/***/ }),

/***/ 5703:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/slideshow");;

/***/ }),

/***/ 5255:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/thumbnails");;

/***/ }),

/***/ 2208:
/***/ ((module) => {

module.exports = import("yet-another-react-lightbox/plugins/zoom");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [247,640], () => (__webpack_exec__(8884)));
module.exports = __webpack_exports__;

})();