(() => {
var exports = {};
exports.id = 367;
exports.ids = [367];
exports.modules = {

/***/ 7112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const CheckBox = ({
  id,
  value,
  onChange
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
    id: id,
    type: "checkbox",
    value: value,
    onChange: onChange,
    className: "\r w-4 h-4 \r m-2\r text-blue-600 \r bg-gray-100 \r border-gray-300 \r rounded \r focus:ring-blue-500 \r dark:focus:ring-blue-600 \r dark:ring-offset-gray-800 \r focus:ring-2 \r dark:bg-gray-700 \r dark:border-gray-600"
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckBox);

/***/ }),

/***/ 3320:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7655);
/* harmony import */ var _components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9219);
/* harmony import */ var _components_misc_CheckBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7112);
/* harmony import */ var _components_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9742);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7789);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5641);
/* harmony import */ var react_phone_number_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8680);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_date_picker__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8140);
/* harmony import */ var react_date_picker__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_date_picker__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6860);
/* harmony import */ var _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3475);
/* harmony import */ var react_date_picker_dist_DatePicker_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1817);
/* harmony import */ var react_date_picker_dist_DatePicker_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_date_picker_dist_DatePicker_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_calendar_dist_Calendar_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8434);
/* harmony import */ var react_calendar_dist_Calendar_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_calendar_dist_Calendar_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_4__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_8__, react_phone_number_input__WEBPACK_IMPORTED_MODULE_9__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__, _services_axios__WEBPACK_IMPORTED_MODULE_15__, _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_16__]);
([_components_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_4__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_8__, react_phone_number_input__WEBPACK_IMPORTED_MODULE_9__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__, _services_axios__WEBPACK_IMPORTED_MODULE_15__, _utils_ToastMessage__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }























const phoneRegEx = /^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,3})|(\(?\d{2,3}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$/;
const schema = yup__WEBPACK_IMPORTED_MODULE_12__.object({
  firstName: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.first-name-required"),
  lastName: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.last-name-required"),
  job: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.job-required"),
  address: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.address-required"),
  postalCode: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.postalCode-required"),
  birthday: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.birthday-required"),
  telephone: yup__WEBPACK_IMPORTED_MODULE_12__.string().matches(phoneRegEx, "errors.phone-validation").required("errors.phone-required"),
  email: yup__WEBPACK_IMPORTED_MODULE_12__.string().email().required("errors.email-required"),
  condition: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.condition-required"),
  reason: yup__WEBPACK_IMPORTED_MODULE_12__.string().required("errors.reason-required")
}).required();

const subscribe = () => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
  const {
    locale
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
  const {
    control,
    handleSubmit,
    formState: {
      errors
    },
    reset
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_8__.useForm)({
    defaultValues: {
      firstName: "",
      lastName: "",
      job: "",
      address: "",
      birthday: "",
      postalCode: "",
      telephone: "",
      email: "",
      condition: "",
      reason: ""
    },
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__.yupResolver)(schema)
  });
  const addMember = (0,react_query__WEBPACK_IMPORTED_MODULE_13__.useMutation)({
    mutationFn: newMember => {
      return _services_axios__WEBPACK_IMPORTED_MODULE_15__/* ["default"].post */ .Z.post("/memberships ", newMember);
    },
    onSuccess: () => {
      (0,_utils_ToastMessage__WEBPACK_IMPORTED_MODULE_16__/* .toastMessage */ .O)(t("message-registered"), "#4CAF50", 2000);
      reset();
    },
    onError: () => {
      (0,_utils_ToastMessage__WEBPACK_IMPORTED_MODULE_16__/* .toastMessage */ .O)(t("registration-failed"), "#d3010ad9", 2000);
    }
  });

  const onSubmit = data => {
    addMember.mutate({
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        job: data.job,
        address: data.address,
        birthday: data.birthday,
        postalCode: data.postalCode,
        telephone: data.telephone,
        email: data.email,
        reason: data.reason
      }
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
    className: "max-w-screen-xl mt-36 mb-4 px-8 xl:px-16 mx-auto",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
        className: "",
        variants: scrollAnimation,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("form", {
          onSubmit: handleSubmit(onSubmit),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex form-group",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "firstName",
                type: "input",
                placeholder: t("membership.name") ?? "Name",
                value: value,
                onChange: onChange
              }),
              name: "firstName"
            }), errors.firstName && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.firstName.message)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "lastName",
                type: "input",
                placeholder: t("membership.family") ?? "Familie",
                value: value,
                onChange: onChange
              }),
              name: "lastName"
            }), errors.lastName && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.lastName.message)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex form-group",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx((react_date_picker__WEBPACK_IMPORTED_MODULE_14___default()), {
                className: "w-full mx-6 mb-6",
                value: value,
                onChange: onChange
              }),
              name: "birthday"
            }), errors.birthday && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.birthday.message)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "job",
                type: "input",
                placeholder: t("membership.job") ?? "Arbeit",
                value: value,
                onChange: onChange
              }),
              name: "job"
            }), errors.job && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.job.message)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex form-group",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "address",
                type: "input",
                placeholder: t("membership.address") ?? "Adresse",
                value: value,
                onChange: onChange
              }),
              name: "address"
            }), errors.address && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.address.message)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "postalCode",
                type: "input",
                placeholder: t("membership.postal-code") ?? "Postleitzahl",
                value: value,
                onChange: onChange
              }),
              name: "postalCode"
            }), errors.postalCode && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.postalCode.message)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex form-group",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30,
                validate: value => (0,react_phone_number_input__WEBPACK_IMPORTED_MODULE_9__.isValidPhoneNumber)(value || "")
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_phone_number_input__WEBPACK_IMPORTED_MODULE_9__["default"], {
                id: "telephone",
                value: value,
                onChange: onChange,
                defaultCountry: locale === "fa" ? "IR" : "DE",
                placeholder: t("membership.phone") ?? "Telefon",
                className: "form-control block\r w-full\r px-3\r py-1.5\r text-base\r font-normal\r text-gray-400\r bg-white bg-clip-padding\r border border-solid border-gray-400\r rounded\r transition\r ease-in-out\r mb-6\r mx-6    \r focus:text-gray-400 focus:bg-white-300 focus:border-orange-500 focus:outline-none\r "
              }),
              name: "telephone"
            }), errors.telephone && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.telephone.message)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true,
                maxLength: 30
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "email",
                type: "input",
                placeholder: t("membership.email-address") ?? "E-Mail-Addresse",
                value: value,
                onChange: onChange
              }),
              name: "email"
            }), errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.email.message)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex form-group",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
              control: control,
              rules: {
                required: true
              },
              render: ({
                field: {
                  onChange,
                  value
                }
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_TextBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                id: "reason",
                type: "textarea",
                rows: 8,
                placeholder: t("membership.request-reason") ?? "Anfragegrund",
                value: value,
                onChange: onChange
              }),
              name: "reason"
            }), errors.reason && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
              className: "text-red-500 text-lg",
              children: t(errors.reason.message)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex my-4 mx-6",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
              className: "flex items-center h-5",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
                name: "condition",
                control: control,
                rules: {
                  required: true
                },
                render: ({
                  field: {
                    onChange,
                    value
                  }
                }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_CheckBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                  value: value,
                  id: "condition",
                  onChange: onChange
                })
              }), errors.condition && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
                className: "text-red-500 text-lg",
                children: t(errors.condition.message)
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
              className: "ml-2 text-sm",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("label", {
                className: "font-medium text-gray-900 dark:text-gray-300",
                children: t("membership.condition-title")
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("p", {
                id: "helper-checkbox-text",
                className: "text-xs font-normal text-gray-300 dark:text-gray-300",
                children: t("membership.condition-context")
              })]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
            className: "flex justify-end mx-6",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
              type: "submit",
              onClick: () => null,
              children: t("button.send") ?? "Schicken"
            })
          })]
        })
      })
    })
  });
};

async function getStaticProps({
  locale
}) {
  return {
    props: _objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__.serverSideTranslations)(locale ?? "de", ["common"]))
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (subscribe);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8434:
/***/ (() => {



/***/ }),

/***/ 1817:
/***/ (() => {



/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 8140:
/***/ ((module) => {

"use strict";
module.exports = require("react-date-picker");

/***/ }),

/***/ 1175:
/***/ ((module) => {

"use strict";
module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

"use strict";
module.exports = import("react-hot-toast");;

/***/ }),

/***/ 8680:
/***/ ((module) => {

"use strict";
module.exports = import("react-phone-number-input");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [710,628], () => (__webpack_exec__(3320)));
module.exports = __webpack_exports__;

})();