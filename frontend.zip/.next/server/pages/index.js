"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 6513:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _EventSlider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9018);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7789);
/* harmony import */ var _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9742);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6014);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Event = ({
  eventTitle,
  eventDescription,
  eventItems
}) => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: " flex flex-col w-full text-center justify-center mt-10",
    id: "Event",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "w-10/12 md:w-7/12 lg:w-1/2 mb-8 mx-auto",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.h3, {
          variants: scrollAnimation,
          className: "text-6xl font-bold 2xl:leading-10 leading-0 text-center text-gray-800",
          children: eventTitle
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.p, {
          variants: scrollAnimation,
          className: "text-base leading-normal text-center text-gray-600 mt-5",
          children: eventDescription
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      className: "w-full flex flex-col my-12",
      viewAmount: 0.4,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_EventSlider__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
          eventItems: eventItems
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
          href: "/plans/event",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            addClass: "",
            type: "button",
            onClick: () => null,
            children: t("button.more-events")
          })
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Event);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Event_EventSlider)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: ./src/components/misc/ButtonOutline.tsx
var ButtonOutline = __webpack_require__(6014);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/data/constants/sliderSettings.js

const settings = {
  dots: true,
  customPaging: function () {
    return /*#__PURE__*/jsx_runtime_.jsx("a", {
      className: "",
      children: /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "mx-2 rounded-l-full rounded-r-full h-4 w-4 block cursor-pointer transition-all "
      })
    });
  },
  dotsClass: "slick-dots w-max absolute mt-20  ",
  infinite: true,
  speed: 500,
  slidesToShow: 3,
  slidesToScroll: 2,
  responsive: [{
    breakpoint: 770,
    settings: {
      slidesToShow: 2,
      slidesToScroll: 2,
      initialSlide: 2
    }
  }, {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  }]
};
;// CONCATENATED MODULE: ./src/components/Event/EventSlider.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var ArrowBack = function ArrowBack(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2",
      d: "m10 19-7-7m0 0 7-7m-7 7h18"
    })
  }));
};

ArrowBack.defaultProps = {
  className: "w-6 h-6",
  fill: "none",
  stroke: "currentColor",
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};

var ArrowNext = function ArrowNext(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2",
      d: "m14 5 7 7m0 0-7 7m7-7H3"
    })
  }));
};

ArrowNext.defaultProps = {
  className: "w-6 h-6",
  fill: "none",
  stroke: "currentColor",
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};






const EventSlider = ({
  eventItems
}) => {
  const {
    0: sliderRef,
    1: setSliderRef
  } = (0,external_react_.useState)();
  const {
    push
  } = (0,router_.useRouter)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((external_react_slick_default()), _objectSpread(_objectSpread({}, settings), {}, {
      arrows: false,
      ref: setSliderRef,
      className: "flex gap-4 items-stretch justify-items-stretch",
      children: eventItems?.map(({
        id,
        attributes
      }) => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "px-3 flex items-stretch",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "border-2 border-gray-500 hover:border-orange-500 transition-all rounded-lg p-8 flex flex-col",
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            className: "items-center",
            src: attributes.thumbnail // height={200}
            // width={200}
            ,
            alt: attributes.title
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "mt-5 text-left line-clamp-2 h-12",
            children: attributes.title
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
            className: "mt-5 text-left line-clamp-6 h-36 mb-4",
            children: ["\u201C", attributes.description, "\u201D."]
          }), /*#__PURE__*/jsx_runtime_.jsx(ButtonOutline/* default */.Z, {
            type: "button",
            onClick: () => push(`/plan/${attributes.slug}`),
            children: "Read More"
          })]
        })
      }, id))
    })), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex w-full items-center justify-end",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-none justify-between w-auto mt-14",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mx-4 flex items-center justify-center h-14 w-14 rounded-full bg-white\r border-orange-500 border hover:bg-orange-500 hover:text-white-500 transition-all\r text-orange-500 cursor-pointer",
          onClick: sliderRef?.slickPrev,
          children: /*#__PURE__*/jsx_runtime_.jsx(ArrowBack, {
            className: "h-6 w-6 "
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center justify-center h-14 w-14 rounded-full bg-white\r border-orange-500 border hover:bg-orange-500 hover:text-white-500 transition-all text-orange-500 cursor-pointer",
          onClick: sliderRef?.slickNext,
          children: /*#__PURE__*/jsx_runtime_.jsx(ArrowNext, {
            className: "h-6 w-6"
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const Event_EventSlider = (EventSlider);

/***/ }),

/***/ 2446:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6014);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5036);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7789);
/* harmony import */ var _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9742);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_3__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_3__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Gallery = () => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
  const {
    data: galleriesData
  } = (0,_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_3__/* .useGalleries */ .n)({
    filters: "filters[banner][$eq]=true",
    pagination: "pagination[start]=0&pagination[limit]=14"
  });
  const galleries = galleriesData ?? [];
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: "flex flex-col justify-center items-center my-10 max-w-screen-xl mx-auto ",
    dir: "ltr",
    id: "Gallery",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "w-10/12 md:w-7/12 lg:w-1/2 mb-8",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.h1, {
          variants: scrollAnimation,
          className: "text-6xl font-bold 2xl:leading-10 leading-0 text-center text-gray-800",
          children: t("gallery.gallery-title")
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.p, {
          variants: scrollAnimation,
          className: "text-base leading-normal text-center text-gray-600 mt-5",
          children: t("gallery.gallery-des")
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "2xl:px-20 lg:px-12 px-4 flex items-start mt-4 mb-6",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "mt-16 md:mt-24",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "flex items-end relative",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[0]?.attributes?.image || "",
                className: "w-20 h-20 xs:hidden md:block lg:hidden xl:block rounded-lg mr-6 object-cover"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[1]?.attributes?.image || "",
                className: "w-36 h-32 xl:w-48 xl:h-36 rounded-lg object-cover"
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
              className: "flex items-center justify-end my-6",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[2]?.attributes?.image || "",
                className: "w-64 h-56 rounded-lg object-cover"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "flex items-start",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[3]?.attributes?.image || "",
                className: "w-32 h-32 xl:w-48 xl:h-48 rounded-lg object-cover"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[4]?.attributes?.image || "",
                className: "xs:hidden md:block lg:hidden xl:block  w-20 h-20 rounded-lg ml-6 flex-shrink-0 object-cover "
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "ml-6 mt-20 md:mt-32 hidden xs:block",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
              src: galleries[5]?.attributes?.image || "",
              className: "w-72 h-80 rounded-lg object-cover"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "flex items-start mt-6",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[6]?.attributes?.image || "",
                className: "w-48 h-48 rounded-lg object-cover"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                src: galleries[7]?.attributes?.image || "",
                className: "xs:hidden md:block lg:hidden xl:block w-20 h-20 rounded-lg ml-6 object-cover "
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "mt-14 ml-6 hidden lg:block",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "lg:flex",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                  src: galleries[8]?.attributes?.image || "",
                  className: "w-96 h-72 rounded-lg object-cover"
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
                  className: "flex ml-6",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                    src: galleries[9]?.attributes?.image || "",
                    className: "w-20 h-20 rounded-lg mt-14 object-cover"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                    src: galleries[10]?.attributes?.image || "",
                    className: "w-20 h-24 rounded-lg ml-6 object-cover"
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                  src: galleries[11]?.attributes?.image || "",
                  className: "ml-6 mt-6 w-48 h-32 rounded-lg object-cover"
                })]
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "mt-6 flex",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                className: "w-48 h-48 rounded-lg object-cover",
                src: galleries[12]?.attributes?.image || ""
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                className: "w-72 h-56 rounded-lg ml-6 object-cover",
                src: galleries[13]?.attributes?.image || ""
              })]
            })]
          })]
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
          href: "/gallery",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            type: "button",
            onClick: () => null,
            children: t("button.more-picture")
          })
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gallery);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6184:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7789);
/* harmony import */ var _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9742);
/* harmony import */ var _misc_Tabs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9274);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks_useMembers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1404);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__, _hooks_useMembers__WEBPACK_IMPORTED_MODULE_6__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__, _hooks_useMembers__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Hero = ({
  tabs
}) => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)("common");
  const {
    locale
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
  const {
    data: members
  } = (0,_hooks_useMembers__WEBPACK_IMPORTED_MODULE_6__/* .useMembers */ .L)({
    locale
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
    className: "max-w-screen-xl mt-24 px-8 xl:px-16 mx-auto",
    id: "About",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        className: "grid grid-flow-row sm:grid-flow-col grid-rows-2 md:grid-rows-1 sm:grid-cols-2 gap-8 py-6 sm:py-16",
        variants: scrollAnimation,
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: " flex flex-col justify-center items-start row-start-2 sm:row-start-1",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("h1", {
            className: "text-3xl lg:text-4xl xl:text-5xl font-medium text-black-600 leading-normal",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("strong", {
              children: t("community.title")
            }), "."]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("p", {
            className: "text-black-500 mt-4 mb-6",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("span", {
              className: "block",
              children: t("community.address")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("span", {
              className: "block",
              children: t("community.phone")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("span", {
              className: "block",
              children: t("community.email")
            })]
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: "flex w-full",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
            className: "h-full w-full",
            variants: scrollAnimation,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
              src: "/assets/iran.png",
              alt: "home",
              quality: 100,
              width: 612,
              height: 383,
              layout: "responsive"
            })
          })
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_misc_Tabs__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            tabs: tabs
          })
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
      className: "relative w-full h-full flex",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        viewAmount: 0.2,
        className: "rounded-lg w-full grid grid-flow-row sm:grid-flow-row grid-cols-1 sm:grid-cols-3 py-9 bg-white-500 z-10",
        children: members?.map(({
          id,
          attributes
        }, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
          className: "flex items-center justify-start sm:justify-center py-4 sm:py-6 w-8/12 px-4 sm:w-auto mx-auto sm:mx-0",
          custom: {
            duration: 2 + index
          },
          variants: scrollAnimation,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: "bg-white font-semibold text-center rounded-3xl border border-gray-100 shadow-lg p-10 max-w-xs",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("img", {
              className: "mb-3 w-32 h-32 rounded-full shadow-lg mx-auto",
              src: attributes.image,
              alt: "product designer"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("h1", {
              className: "text-lg text-gray-700",
              children: [" ", attributes.name, " "]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("h3", {
              className: "text-sm text-gray-400 ",
              children: [" ", attributes.role, " "]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: "text-xs text-gray-400 mt-4 h-[98px] overflow-y-auto custom-scrollbar",
              children: attributes.description
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "flex justify-center gap-2 mt-3",
              children: attributes?.socials.data?.map(({
                id,
                attributes
              }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("a", {
                href: attributes.link,
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("img", {
                  src: attributes.icon,
                  alt: attributes.name
                })
              }, id))
            })]
          })
        }, id))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: "absolute bg-black-600 opacity-5 w-11/12 roudned-lg h-64 sm:h-48 top-0 mt-8 mx-auto left-0 right-0",
        style: {
          filter: "blur(114px)"
        }
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3462:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7789);
/* harmony import */ var _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9742);
/* harmony import */ var _misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7655);
/* harmony import */ var _Event_Event__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6513);
/* harmony import */ var _Project__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3012);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_0__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_2__, _Event_Event__WEBPACK_IMPORTED_MODULE_4__, _Project__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_0__, _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_2__, _Event_Event__WEBPACK_IMPORTED_MODULE_4__, _Project__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Plans = ({
  eventTitle,
  eventDescription,
  eventItems,
  projectTitle,
  projectDescription,
  projectItems,
  subscribeClick
}) => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)("common");
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
    className: "bg-gradient-to-b from-white-300 to-white-500 py-14",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "px-6 sm:px-8 xl:px-16 mx-auto flex flex-col text-center justify-center max-w-screen-xl ",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Project__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        projectTitle: projectTitle,
        projectDescription: projectDescription,
        projectItems: projectItems
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-col my-8",
        id: "Event",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Event_Event__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          eventTitle: eventTitle,
          eventDescription: eventDescription,
          eventItems: eventItems
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
          className: "relative mt-8 ",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_0__.motion.div, {
            variants: scrollAnimation,
            custom: {
              duration: 3
            },
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "absolute rounded-xl  py-8 sm:py-14 px-6 sm:px-12 lg:px-16 w-full flex flex-col sm:flex-row justify-between items-center z-10 bg-white-500",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
                className: "flex flex-col text-left w-10/12 sm:w-7/12 lg:w-5/12 mb-6 sm:mb-0",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h5", {
                  className: "text-black-600 text-xl sm:text-2xl lg:text-3xl leading-relaxed font-medium",
                  children: t("membership.membership-des")
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_misc_ButtonPrimary__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                type: "button",
                onClick: subscribeClick,
                children: t("membership.membership")
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
              className: "absolute bg-black-600 opacity-5 w-11/12 roudned-lg h-60 sm:h-56 top-0 mt-8 mx-auto left-0 right-0",
              style: {
                filter: "blur(114px)"
              }
            })]
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Plans);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3012:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6014);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1422);
/* harmony import */ var _utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7789);
/* harmony import */ var _Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9742);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Project = ({
  projectTitle,
  projectDescription,
  projectItems
}) => {
  const scrollAnimation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_utils_getScrollAnimation__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(), []);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
  const {
    push
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
    className: "flex flex-col items-center justify-center",
    id: "Project",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
      className: "w-10/12 md:w-7/12 lg:w-1/2 mb-8",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.h1, {
          variants: scrollAnimation,
          className: "text-6xl font-bold 2xl:leading-10 leading-0 text-center text-gray-800",
          children: projectTitle
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.p, {
          variants: scrollAnimation,
          className: "text-base leading-normal text-center text-gray-600 mt-5",
          children: projectDescription
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: "flex flex-wrap gap-2 mt-4 items-center justify-between px-3",
          "aria-label": "schedule events",
          children: projectItems.map(({
            id,
            attributes
          }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: "w-[49%] h-60  border-2 border-gray-100",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              date: "2023",
              thumbnail: attributes.thumbnail,
              title: attributes.title,
              description: attributes.description,
              btnText: t("button.read-info"),
              readMore: () => push(`/plan/${attributes.slug}`)
            })
          }, id))
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Layout_ScrollAnimationWrapper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        variants: scrollAnimation,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
          href: "/plans/project",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_misc_ButtonOutline__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            addClass: "mt-8",
            type: "button",
            onClick: () => null,
            children: t("button.read-info")
          })
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Project);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);






const Tabs = ({
  tabs
}) => {
  const {
    0: currentTab,
    1: setCurrentTab
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(tabs[0]);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("home");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: "mx-auto w-full  sm:border-b-2  border-gray-100",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: "mx-auto max-w-md sm:hidden rounded-lg border border-gray-100 overflow-hidden",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("label", {
          htmlFor: "current-tab",
          className: "sr-only",
          children: "Select a tab"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("select", {
          name: "current-tab",
          id: "current-tab",
          defaultValue: tabs.find(tab => tab.title === currentTab.title)?.title,
          className: "form-select w-full sm:w-auto block border-none text-sm text-gray-500 font-semibold cursor-pointer focus:ring-0",
          children: tabs.map(tab => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("option", {
            value: tab.title,
            onClick: () => setCurrentTab(tab),
            children: tab.title
          }, tab.title))
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "-mb-px hidden sm:block",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("nav", {
          "aria-label": "Tabs",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("ul", {
            className: "flex flex-wrap justify-start space-x-5",
            children: tabs.map(tab => {
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                className: `flex border-b-2 text-base 
                      ${tab.title === currentTab.title ? "border-orange-500 text-orange-500" : "border-transparent text-gray-400 hover:text-gray-400 hover:border-gray-400"}`,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("button", {
                  type: "button",
                  className: "px-2 pb-5 inline-flex items-center font-semibold",
                  onClick: () => setCurrentTab(tab),
                  children: t(tab.title || "")
                })
              }, tab.title);
            })
          })
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "text-black-500 my-6  mx-auto max-h-80 overflow-y-auto custom-scrollbar",
      dangerouslySetInnerHTML: {
        __html: t(currentTab?.context || "")
      }
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tabs);

/***/ }),

/***/ 4284:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Hero__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6184);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Hero__WEBPACK_IMPORTED_MODULE_0__]);
_components_Hero__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const HeroContainer = () => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
  const tabs = [{
    title: t("union-title"),
    context: t("union-description")
  }, {
    title: t("partners-and-sponsors-title"),
    context: t("partners-and-sponsors-description")
  }, {
    title: t("statute-title"),
    context: t("statute-description")
  }];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components_Hero__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
    tabs: tabs
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroContainer);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9099:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Plans__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3462);
/* harmony import */ var _hooks_usePlans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2247);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Plans__WEBPACK_IMPORTED_MODULE_2__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_3__]);
([_components_Plans__WEBPACK_IMPORTED_MODULE_2__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const PlansContainer = () => {
  const {
    locale,
    push
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
  const {
    data: eventsData
  } = (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_3__/* .usePlans */ .x)({
    locale,
    filters: "filters[type][$eq]=event",
    pagination: "pagination[start]=0&pagination[limit]=6"
  });
  const events = eventsData?.data ?? [];
  const {
    data: projectsData
  } = (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_3__/* .usePlans */ .x)({
    locale,
    filters: "filters[type][$eq]=project",
    pagination: "pagination[start]=0&pagination[limit]=6"
  });
  const projects = projectsData?.data ?? [];

  const subscribeClick = () => {
    push("/subscribe");
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_components_Plans__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    eventTitle: t("plan.event-title"),
    eventDescription: t("plan.event-des"),
    eventItems: events,
    projectTitle: t("plan.project-title"),
    projectDescription: t("plan.project-des"),
    projectItems: projects,
    subscribeClick: subscribeClick
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlansContainer);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5036:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ useGalleries),
/* harmony export */   "w": () => (/* binding */ fetchGalleries)
/* harmony export */ });
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6860);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9651);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_axios__WEBPACK_IMPORTED_MODULE_0__]);
_services_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const fetchGalleries = async (locale, filters, pagination) => {
  const res = await _services_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`galleries?populate=image${`&${pagination}`}${`&${filters}`}&locale=${locale}`);

  if (res.status === 200) {
    res.data.data = (0,_utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__/* .getImageLink */ .o)(res.data.data, "image");
  }

  return res?.data.data;
};

const useGalleries = ({
  locale = "de",
  filters,
  pagination
}) => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)(["galleries", filters, pagination, locale], () => fetchGalleries(locale, filters, pagination));
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ useMembers)
/* harmony export */ });
/* unused harmony export fetchMembers */
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6860);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9651);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_axios__WEBPACK_IMPORTED_MODULE_0__]);
_services_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const fetchMembers = async locale => {
  const res = await _services_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`members?populate=*&pagination[start]=0&pagination[limit]=20&locale=${locale}`);

  if (res.status === 200) {
    res.data.data = (0,_utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__/* .getImageLink */ .o)(res.data.data, "image");
  }

  return res?.data.data;
};

const useMembers = ({
  locale = "de"
}) => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)(["galleries", locale], () => fetchMembers(locale));
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2779:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Gallery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2446);
/* harmony import */ var _container_Plans__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9099);
/* harmony import */ var _container_Hero__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4284);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2247);
/* harmony import */ var _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5036);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Gallery__WEBPACK_IMPORTED_MODULE_1__, _container_Plans__WEBPACK_IMPORTED_MODULE_2__, _container_Hero__WEBPACK_IMPORTED_MODULE_3__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__]);
([_components_Gallery__WEBPACK_IMPORTED_MODULE_1__, _container_Plans__WEBPACK_IMPORTED_MODULE_2__, _container_Hero__WEBPACK_IMPORTED_MODULE_3__, _hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function Home() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_container_Hero__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Gallery__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_container_Plans__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})]
  });
}
async function getStaticProps({
  locale
}) {
  const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_4__.QueryClient();
  const eventFilters = "filters[type][$eq]=event";
  const projectFilters = "filters[type][$eq]=project";
  const pagination = "pagination[start]=0&pagination[limit]=6";
  const galleryFilters = "filters[banner][$eq]=true";
  const galleryPagination = "pagination[start]=0&pagination[limit]=14";
  await queryClient.prefetchQuery(["plans", eventFilters, pagination, locale ?? "de", undefined], () => (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__/* .fetchPlans */ .Z)(locale ?? "de", eventFilters, pagination, undefined));
  await queryClient.prefetchQuery(["plans", projectFilters, pagination, locale ?? "de", undefined], () => (0,_hooks_usePlans__WEBPACK_IMPORTED_MODULE_5__/* .fetchPlans */ .Z)(locale ?? "de", projectFilters, pagination, undefined));
  await queryClient.prefetchQuery(["galleries", galleryFilters, galleryPagination, locale], () => (0,_hooks_useGalleries__WEBPACK_IMPORTED_MODULE_6__/* .fetchGalleries */ .w)(locale ?? "de", galleryFilters, galleryPagination));
  return {
    revalidate: 60 * 60 * 24,
    // 24H
    props: _objectSpread({
      dehydratedState: JSON.parse(JSON.stringify((0,react_query__WEBPACK_IMPORTED_MODULE_4__.dehydrate)(queryClient)))
    }, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_0__.serverSideTranslations)(locale ?? "de", ["common", "home"]))
  };
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,505,676,664,675,247,710,422,14], () => (__webpack_exec__(2779)));
module.exports = __webpack_exports__;

})();