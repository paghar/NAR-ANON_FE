"use strict";
exports.id = 640;
exports.ids = [640];
exports.modules = {

/***/ 2013:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_photo_album__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7353);
/* harmony import */ var yet_another_react_lightbox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5717);
/* harmony import */ var yet_another_react_lightbox_plugins_fullscreen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1485);
/* harmony import */ var yet_another_react_lightbox_plugins_slideshow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5703);
/* harmony import */ var yet_another_react_lightbox_plugins_thumbnails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5255);
/* harmony import */ var yet_another_react_lightbox_plugins_zoom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2208);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_photo_album__WEBPACK_IMPORTED_MODULE_0__, yet_another_react_lightbox__WEBPACK_IMPORTED_MODULE_1__, yet_another_react_lightbox_plugins_fullscreen__WEBPACK_IMPORTED_MODULE_2__, yet_another_react_lightbox_plugins_slideshow__WEBPACK_IMPORTED_MODULE_3__, yet_another_react_lightbox_plugins_thumbnails__WEBPACK_IMPORTED_MODULE_4__, yet_another_react_lightbox_plugins_zoom__WEBPACK_IMPORTED_MODULE_5__]);
([react_photo_album__WEBPACK_IMPORTED_MODULE_0__, yet_another_react_lightbox__WEBPACK_IMPORTED_MODULE_1__, yet_another_react_lightbox_plugins_fullscreen__WEBPACK_IMPORTED_MODULE_2__, yet_another_react_lightbox_plugins_slideshow__WEBPACK_IMPORTED_MODULE_3__, yet_another_react_lightbox_plugins_thumbnails__WEBPACK_IMPORTED_MODULE_4__, yet_another_react_lightbox_plugins_zoom__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const GalleryAlbum = ({
  galleries
}) => {
  const {
    0: index,
    1: setIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(-1);
  const breakpoints = [3840, 2400, 1080, 640, 384, 256, 128, 96, 64, 48];
  const photos = galleries?.map(({
    attributes
  }) => {
    const width = breakpoints[0];
    const height = +attributes.height / +attributes.width * width;
    return {
      src: attributes.image,
      width,
      height,
      images: breakpoints.map(breakpoint => {
        const imageHeight = Math.round(+attributes.height / +attributes.width * breakpoint);
        return {
          src: attributes.image,
          width: breakpoint,
          height: imageHeight
        };
      })
    };
  });
  const slides = photos?.map(({
    src,
    width,
    height,
    images
  }) => ({
    src,
    width,
    height,
    srcSet: images?.map(image => ({
      src: image.src,
      width: image.width,
      height: image.height
    }))
  }));
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_photo_album__WEBPACK_IMPORTED_MODULE_0__["default"], {
      photos: photos || [],
      layout: "rows",
      targetRowHeight: 150,
      onClick: ({
        index
      }) => setIndex(index)
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(yet_another_react_lightbox__WEBPACK_IMPORTED_MODULE_1__["default"], {
      slides: slides || [],
      open: index >= 0,
      index: index,
      close: () => setIndex(-1),
      plugins: [yet_another_react_lightbox_plugins_fullscreen__WEBPACK_IMPORTED_MODULE_2__["default"], yet_another_react_lightbox_plugins_slideshow__WEBPACK_IMPORTED_MODULE_3__["default"], yet_another_react_lightbox_plugins_thumbnails__WEBPACK_IMPORTED_MODULE_4__["default"], yet_another_react_lightbox_plugins_zoom__WEBPACK_IMPORTED_MODULE_5__["default"]]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GalleryAlbum);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5036:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ useGalleries),
/* harmony export */   "w": () => (/* binding */ fetchGalleries)
/* harmony export */ });
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6860);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9651);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_axios__WEBPACK_IMPORTED_MODULE_0__]);
_services_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const fetchGalleries = async (locale, filters, pagination) => {
  const res = await _services_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`galleries?populate=image${`&${pagination}`}${`&${filters}`}&locale=${locale}`);

  if (res.status === 200) {
    res.data.data = (0,_utils_getImageLink__WEBPACK_IMPORTED_MODULE_2__/* .getImageLink */ .o)(res.data.data, "image");
  }

  return res?.data.data;
};

const useGalleries = ({
  locale = "de",
  filters,
  pagination
}) => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)(["galleries", filters, pagination, locale], () => fetchGalleries(locale, filters, pagination));
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;