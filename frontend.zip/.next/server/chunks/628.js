"use strict";
exports.id = 628;
exports.ids = [628];
exports.modules = {

/***/ 9219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const TextBox = ({
  id,
  type,
  rows,
  placeholder,
  value,
  onChange
}) => {
  const renderElement = type === "input" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
    id: id,
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: onChange,
    className: "form-control block\r w-full\r px-3\r py-1.5\r text-base\r font-normal\r text-gray-400\r bg-white bg-clip-padding\r border border-solid border-gray-400\r rounded\r transition\r ease-in-out\r mb-6\r mx-6\r focus:text-gray-400 focus:bg-white-300 focus:border-orange-500 focus:outline-none"
  }) : type === "textarea" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("textarea", {
    id: "reasonText",
    rows: rows,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    className: "\r form-control\r block\r w-full\r px-3\r py-1.5\r text-base\r font-normal\r text-gray-400\r bg-white bg-clip-padding\r border border-solid border-gray-400\r rounded\r transition\r ease-in-out\r mb-6\r mx-6               \r focus:text-gray-400 focus:bg-white focus:border-orange-500 focus:outline-none"
  }) : null;
  return renderElement;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextBox);

/***/ }),

/***/ 6860:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

let baseURL = "https://api.irankultursachsen.com/api/";

if (process.env.NEXT_PUBLIC_API_URL) {
  baseURL = `${process.env.NEXT_PUBLIC_API_URL}/api/`;
}

const requestOnFullFilled = config => {
  config.baseURL = baseURL;
  return config;
};

const requestOnRejected = error => Promise.reject(error);

const responseOnFullFilled = response => response;

const responseOnRejected = error => {
  throw error;
};

axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.request.use(requestOnFullFilled, requestOnRejected);
axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.response.use(responseOnFullFilled, responseOnRejected);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0__["default"]);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3475:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ toastMessage)
/* harmony export */ });
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6201);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_0__]);
react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function toastMessage(text, color, duration) {
  return (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_0__.toast)(text, {
    duration: duration || 4000,
    position: "bottom-center",
    style: {
      color: "#fff",
      backgroundColor: color || "rgba(0, 0, 0, 0.85)",
      fontSize: "14px",
      padding: "24px 32px",
      letterSpacing: "0.25px"
    }
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;