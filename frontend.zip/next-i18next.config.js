module.exports = {
  i18n: {
    defaultLocale: "de",
    locales: ["fa", "de"],
    localeDetection: false
  }
};
